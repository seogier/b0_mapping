"""Tool for mapping the B0 of a magnet using a 3D printer as a motion stage/positioning system"""
import print3d
import lakeshore
import csv
import argparse
import numpy as np
import time
from alive_progress import alive_bar

def cube_gen(side, center, spacing):
    """Generate a numpy array of points occupying a cube of a given side length around a center with a given spacing
    Points are generated at the given spacing moving outwards from the center, which is always included.
    If the edges aren't an even multiple of the spacing, the

    args:
        side:    side length in mm
        center:  (x, y, z) of cube center, in mm
        spacing: spacing of points, in mm
    
    returns:
        points:  2D numpy array of points
                 x0, y0, z0
                 x0, y0, z1
                 ...
                 xN, yN, zN
    """
    
    upper_axis = np.arange(0, side/2+spacing, spacing)
    lower_axis = np.arange(-1*spacing, -1*(side/2+spacing), -1*spacing)[::-1]
    axis = np.concatenate((upper_axis,lower_axis))

    X, Y, Z = np.meshgrid(axis+center[0], axis+center[1], axis+center[2], indexing='ij')
    X = X.flatten()
    Y = Y.flatten()
    Z = Z.flatten()

    points = np.stack((X, Y, Z)).T
    points = points[np.lexsort((points[:,0],points[:,1],points[:,2]))]
    return points

def sphere_gen(diameter, center, spacing):
    """Generate a list of points occupying a sphere of a given diameter

    args:
        diameter: sphere diameter in mm
        center:   (x, y, z) of sphere center, in mm
        spacing:  spacing of points, in mm
    
    returns:
        points:  2D numpy array of points
                 x0, y0, z0
                 x0, y0, z1
                 ...
                 xN, yN, zN
    """

    cube = cube_gen(diameter, center, spacing)
    distance = np.sqrt((cube[:,0]-center[0])**2 + (cube[:,1]-center[1])**2 + (cube[:,2]-center[2])**2)
    index = distance <= diameter/2
    sphere = cube[index,:]
    return sphere

def cylinder_gen(diameter, center, spacing):
    """Generate a list of points occupying a right cylinder (d=h) of a given diameter/height

    args:
        diameter: cylinder diameter in mm
        center:   (x, y, z) of cylinder center, in mm
        spacing:  spacing of points, in mm
    
    returns:
        points:  2D numpy array of points
                 x0, y0, z0
                 x0, y0, z1
                 ...
                 xN, yN, zN
    """

    cube = cube_gen(diameter, center, spacing)
    distance = np.sqrt((cube[:,0]-center[0])**2 + (cube[:,1]-center[1])**2)
    index = distance <= diameter/2
    cylinder = cube[index,:]
    return cylinder

def circle_gen(diameter, center, spacing):
    """Generate a list of points occupying a circle in the X/Y plane of the printer of a given diameter

    args:
        diameter: circle diameter in mm
        center:   (x, y, z) of circle center, in mm
        spacing:  spacing of points, in mm
    
    returns:
        points:  2D numpy array of points
                 x0, y0, z0
                 x0, y0, z1
                 ...
                 xN, yN, zN
    """

    upper_axis = np.arange(0, diameter/2+spacing, spacing)
    lower_axis = np.arange(-1*spacing, -1*(diameter/2+spacing), -1*spacing)[::-1]
    axis = np.concatenate((upper_axis,lower_axis))

    X, Y = np.meshgrid(axis+center[0], axis+center[1], indexing='ij')
    X = X.flatten()
    Y = Y.flatten()
    Z = (np.zeros_like(X)+center[2]).flatten()

    rect = np.stack((X, Y, Z)).T
    rect = rect[np.lexsort((rect[:,0],rect[:,1],rect[:,2]))]

    distance = np.sqrt((rect[:,0]-center[0])**2 + (rect[:,1]-center[1])**2)
    index = distance <= diameter/2
    circle = rect[index,:]

    return circle

if __name__ == '__main__':
    parser = argparse.ArgumentParser('Map the B0 of a magnet with a 3D printer and Hall probe.')
    parser.add_argument('probe_port', action='store', help='Port for Hall probe communication (e.g., COM1)')
    parser.add_argument('printer_port', action='store', help='Port for 3D printer communication (e.g., COM5)')
    parser.add_argument('shape', type=str, action='store', choices=['cube', 'cylinder', 'sphere', 'circle'], help='Shape of sampling pattern', default='sphere')
    parser.add_argument('-d', '--diameter', action='store', default=100, help='Diameter of measurement volume (and length of cylinder if applicable) in mm')
    parser.add_argument('-c', '--center', action='store', nargs=3, default=[110,110,250], type=float)
    parser.add_argument('-s', '--save_name', action='store', required=True)
    parser.add_argument('-p', '--spacing', action='store', default=2.5, type=float, help='Measurement point spacing in mm')
    parser.add_argument('-r', '--restart', action='store', default=0, type=int, help='Point to start at if restarting')

    args = parser.parse_args()
    port_lakeshore = args.probe_port
    port_printer = args.printer_port
    shape = args.shape
    diameter = args.diameter
    center = args.center
    save_name = args.save_name
    spacing = args.spacing
    start = args.restart

    print(f'Generating a {shape} of diameter {diameter} mm centered about ({center[0]},{center[1]},{center[2]})')
    print(f'Points are spaced every {spacing} mm')

    if start != 0:
        print(f'Starting at point {start}')

    probe = lakeshore.LakeshoreF71(port_lakeshore)

    printer = print3d.Printer(port_printer)

    home = input("Home printer?[y/n]")
    if home.lower() == 'y':
        print('Homing Printer, please wait.')
        printer.home()
        printer.wait()

    if shape == 'cube':
        points = cube_gen(diameter, center, spacing)
    elif shape == 'cylinder':
        points = cylinder_gen(diameter, center, spacing)
    elif shape == 'sphere':
        points = sphere_gen(diameter, center, spacing)
    elif shape == 'circle':
        points = circle_gen(diameter, center, spacing)

    n_points = points.shape[0]
    with open(save_name, 'w', newline='') as csvfile:
        csvwriter = csv.writer(csvfile, dialect='excel')
        csvwriter.writerow(['X', 'Y', 'Z', 'Bz'])
        with alive_bar(n_points, dual_line=True) as bar:
            bar.title('B0 Mapping in Progress')
            if start !=0:
                bar(start, skipped=True)

            for i in range(start, n_points):
                point = points[i,:]
                printer.move_wait(point)
                time.sleep(0.5)
                field = probe.get_field()
                bar.text(f'{point}: {field}')
                csvwriter.writerow([*point,field])
                bar()
    printer.beep() # Let everyone know you're done!

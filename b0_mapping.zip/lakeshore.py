import pyvisa

class LakeshoreF71():
    """Defines an interface to the Lakeshore Teslameter"""
    def __init__(self,port):
        self.port = port
        rm = pyvisa.ResourceManager()
        self.inst = rm.open_resource(self.port, timeout=10000, baud_rate=115200)
        print('Tesla Meter Name:',self.inst.query('*IDN?'))

    def get_field(self, axis='X'):
        
        field = self.inst.query(f'FETCh:DC? {axis}')
        return float(field)